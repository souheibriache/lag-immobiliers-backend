import { IsUUID, IsInt, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ReorderItem {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  id: string;

  @ApiProperty({ minimum: 0 })
  @IsInt()
  @Min(0)
  order: number;
}

export class ReorderAccompaniementsDto {
  @ApiProperty({ type: [ReorderItem] })
  items: ReorderItem[];
}
