export enum ProductTypeEnum {
  PRODUCT = 'PRODUCT',
  BOOK = 'BOOK',
}
