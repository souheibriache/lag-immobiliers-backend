export enum SupportCategory {
  CLIENT = 'CLIENT',
  VISITOR = 'VISITOR',
}
